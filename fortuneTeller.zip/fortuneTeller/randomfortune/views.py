from django.shortcuts import render
import random

# Create your views here.
def randomfortune(request):
    fortunelist = [
    "Believe in yourself, even when others doubt you.",
    "Today is a great day to start something new.",
    "A new opportunity will soon open for you.",
    "Your kindness will return to you in unexpected ways.",
    "Great success begins with small steps.",
    "You have the strength to overcome your challenges.",
    "A pleasant surprise is waiting for you.",
    "Your patience will bring rewarding results.",
    "Never underestimate the power of a positive attitude.",
    "Your next chapter will be better than the last.",
    "A difficult problem will soon become clearer.",
    "Your generosity will make a lasting difference.",
    "An exciting adventure may be closer than you think.",
    "Small victories deserve to be celebrated.",
    "You are capable of achieving more than you imagine.",
    "A fresh beginning is always possible.",
    "Your determination will take you far.",
    "Listen carefully; an important lesson is nearby.",
    "Someone will soon recognize your talents.",
    "Your future holds opportunities for growth.",
    "A little courage can change everything.",
    "Today, choose progress over perfection.",
    "The right opportunity rewards preparation.",
    "Your efforts are building something meaningful.",
    "An unexpected conversation may inspire you.",
    "You deserve to celebrate your progress.",
    "A wise choice today can improve tomorrow.",
    "Your potential is greater than your fears.",
    "Kindness will always be a worthwhile investment.",
    "A new skill will create new possibilities.",
    "Something wonderful can begin with one decision.",
    "Do not fear failure; learn from it.",
    "Your discipline will bring you closer to your goals.",
    "Better days are possible, even after difficult ones.",
    "A helpful person may soon enter your life.",
    "Success grows where preparation meets opportunity.",
    "A moment of patience can prevent a lifetime of regret.",
    "Your next success may begin with today's effort.",
    "Believe that you can learn what you do not yet know.",
    "A thoughtful gesture will brighten someone's day.",
    "You are stronger than yesterday's difficulties.",
    "A new perspective will bring fresh understanding.",
    "Your future is shaped by the choices you make.",
    "Celebrate others without forgetting your own worth.",
    "A little planning today will save time tomorrow.",
    "You will grow through the challenges you face.",
    "Good opportunities often begin with curiosity.",
    "Your calmness will help you handle uncertainty.",
    "Take the first step, even if it feels small.",
    "Your determination is stronger than your excuses.",
    "The answer may appear when you ask a better question.",
    "Your goals become achievable when you make a plan.",
    "You can turn today's lesson into tomorrow's strength.",
    "Stay curious; knowledge will expand your world.",
    "A little optimism can change your entire outlook.",
    "Your consistency will matter more than occasional perfection.",
    "Your efforts may inspire someone who is watching.",
    "One good decision can start a chain of positive changes.",
    "Your journey is unique; give yourself time to grow."
]
    
    fortune = random.choice(fortunelist)
    
    return render(request, 'randomfortune/fortune.html', {'fortune':fortune})


