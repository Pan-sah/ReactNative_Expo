from django.contrib import admin
from django.urls import path
from randomfortune.views import randomfortune

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', randomfortune, name='randomfortune'),
]